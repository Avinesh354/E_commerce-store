import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import HeroBanner from "../components/HeroBanner";
import Loading from "../components/Loading";
import ProductCard from "../components/ProductCard";
import ProductImage from "../components/ProductImage";
import TrustStrip from "../components/TrustStrip";
import { useCatalog } from "../context/CatalogContext";
import useSlowLoading from "../hooks/useSlowLoading";
import { offPercent } from "../utils/format";

const COPY = {
  Electronics: {
    title: "Gadgets that keep up with you",
    text: "Headphones, smart watches, chargers and more.",
    color: "#1e40af",
  },
  Furniture: {
    title: "Make your home feel finished",
    text: "Sofas, beds, desks and storage for every room.",
    color: "#9a3412",
  },
  Fashion: {
    title: "A fresh wardrobe for every day",
    text: "T-shirts, jeans, shoes and accessories.",
    color: "#9d174d",
  },
  "Home & Kitchen": {
    title: "Everything for a better kitchen",
    text: "Cookware, appliances, bedding and lighting.",
    color: "#166534",
  },
  Books: {
    title: "Read something worth keeping",
    text: "Programming, productivity and bestselling titles.",
    color: "#5b21b6",
  },
};

export default function Home() {
  const { categories, loaded } = useCatalog();
  const [sections, setSections] = useState(null);

  useEffect(() => {
    if (!loaded) return undefined;
    let active = true;

    Promise.all(
      categories.map((category) =>
        api
          .get("/products/", { params: { category: category.id } })
          .then((res) => ({ category, count: res.data.count, products: res.data.results }))
          .catch(() => ({ category, count: 0, products: [] }))
      )
    ).then((list) => {
      if (active) setSections(list.filter((s) => s.products.length > 0));
    });

    return () => {
      active = false;
    };
  }, [loaded, categories]);

  const loading = sections === null;
  const slow = useSlowLoading(loading);

  if (loading) return <Loading slow={slow} />;

  if (sections.length === 0) {
    return (
      <div className="empty">
        <h2>The store is getting stocked</h2>
        <p className="muted">Products will appear here as soon as they are added.</p>
      </div>
    );
  }

  const slides = sections.slice(0, 4).map((s) => {
    const copy = COPY[s.category.name] || {};
    const best = Math.max(...s.products.map((p) => offPercent(p.price, p.id)));
    return {
      key: s.category.id,
      title: copy.title || `Shop ${s.category.name}`,
      text: copy.text || `Browse ${s.count} products in ${s.category.name}.`,
      offer: `Up to ${best}% off`,
      cta: `Shop ${s.category.name}`,
      to: `/products?category=${s.category.id}`,
      color: copy.color || "#1e3a8a",
      images: s.products,
    };
  });

  return (
    <>
      <HeroBanner slides={slides} />
      <TrustStrip />

      <section className="block">
        <h2 className="block-title">Shop by category</h2>
        <div className="cat-tiles">
          {sections.map((s) => (
            <Link key={s.category.id} to={`/products?category=${s.category.id}`} className="cat-tile">
              <div className="cat-tile-media">
                <ProductImage product={s.products[0]} />
              </div>
              <div className="cat-tile-text">
                <h3>{s.category.name}</h3>
                <p className="muted">{s.count} products</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {sections.map((s) => (
        <section className="block" key={s.category.id}>
          <div className="block-head">
            <h2 className="block-title">Best of {s.category.name}</h2>
            <Link to={`/products?category=${s.category.id}`} className="view-all">
              View all
            </Link>
          </div>
          <div className="row-scroll">
            {s.products.slice(0, 6).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      ))}
    </>
  );
}
